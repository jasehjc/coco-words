# GitHub Pages 与 iPhone 使用

## GitHub Pages
当前推荐：
- Public repository
- Settings → Pages
- Deploy from a branch
- main
- /(root)

仓库根目录至少包含：
- index.html
- manifest.webmanifest
- sw.js
- icon.svg

Push / Commit 到 main 后，Pages 自动部署。

## iPhone
1. Safari 打开 GitHub Pages 地址
2. 确认 Wi-Fi / 蜂窝不开代理也能访问
3. 分享 → 添加到主屏幕
4. 之后从“抠抠单词”图标打开

## 数据
- 同一部 iPhone 的主屏幕 Web App 保存本地数据
- 关闭 / 重启一般保留
- 删除网站数据或换域名可能丢
- 使用设置里的导出备份

## 多手机
- 同一网址可以在多台 iPhone 安装
- 数据各自独立
- 不会自动同步

## 更新
- 保持同一 GitHub Pages 地址
- main 更新后自动重新发布
- 注意 Service Worker 缓存可能导致短时间旧版
