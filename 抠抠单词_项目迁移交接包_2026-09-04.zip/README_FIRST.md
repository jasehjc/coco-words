# 抠抠单词项目迁移包

建议阅读顺序：

1. `PROJECT_HANDOFF.md` —— 完整项目上下文
2. `CONTINUE_IN_CODEX.md` —— 可直接贴给 Codex / 新 ChatGPT
3. `PRODUCT_REQUIREMENTS.md` —— 第一版边界
4. `ROADMAP.md` —— 下一步版本路线
5. `DEPLOYMENT.md` —— GitHub Pages / iPhone 使用
6. `source/` —— 当前最新源码
7. `context.json` —— 机器可读摘要

这个包的目的不是保存逐字聊天记录，而是保存“后续继续开发真正需要的全部上下文”。

如果迁移到 Codex：
- 把整个文件夹作为项目上下文
- 让 Codex 先读 `PROJECT_HANDOFF.md`
- 然后让它按 `CONTINUE_IN_CODEX.md` 继续

如果迁移到新的 ChatGPT 对话：
- 上传此 ZIP
- 告诉新对话：“先读 PROJECT_HANDOFF.md，再继续开发”
