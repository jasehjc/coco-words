# 可直接粘贴给 Codex / 新 ChatGPT 的继续开发提示词

我要继续开发一个叫“抠抠单词”的 iPhone 优先 CET-6 学习计划 PWA。

请先完整阅读：
1. PROJECT_HANDOFF.md
2. PRODUCT_REQUIREMENTS.md
3. ROADMAP.md
4. source/ 里的现有源码

项目目前是纯静态 PWA，通过 GitHub Pages 发布；数据使用 localStorage 保存在 iPhone 本地，不需要后端、账号或云同步。

产品定位必须保持轻量：
- 主要功能：打卡、规划、少量记录
- 不要做成复杂学习平台
- 首页 5 秒内知道做什么
- 70% 即达标
- 不补历史欠账
- 科研忙时用忙碌模式
- 六级过线是阶段目标，持续英语学习才是长期目标

UI 方向：
- iPhone
- 大号“抠抠单词”
- 马卡龙 / 复古色
- 奶油底、薄荷绿、莓果、奶油黄
- 大圆角
- 简洁高级但不要性冷淡
- 有一点科技感
- 文案短，不要 AI 味

当前优先开发 v3.4：
1. 最近 7 天打卡点阵
2. 全面检查周进度算法和试运行/正式模式统计口径
3. 改善 Service Worker 更新，避免 iPhone 长时间拿旧缓存
4. 真机 UI 微调

重要：
- 先确认用户 GitHub Pages 上目前部署的是 v3.2 还是 v3.3。
- v3.3 的关键修复：试运行的“正式模式预览”使用独立 preview state，不能污染 Week 1 正式数据。
- 小项目不要强迫使用 GitHub Desktop；优先通过 GitHub 网页界面维护。
- 每次改动请告诉我：改了什么、哪些文件、如何通过 GitHub 网页更新、建议 commit message。
