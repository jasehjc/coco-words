# Roadmap

## v3.4
- 最近 7 天打卡点阵
- 进度算法单元式自检
- Service Worker 更新策略改进
- iPhone 真机 UI 微调

## v3.5
- 成就 / 奖励动画轻量优化
- 真题命名优化
- 备份 UX 优化

## v4.0
- 12 月考后“保持模式”
- 下一次六级计划入口
- 长期英语持续学习

## Future App
只有真正对外推出时再考虑：
- iOS / Flutter
- 登录 / 云同步
- 多设备
- 原生通知
- TestFlight / App Store
